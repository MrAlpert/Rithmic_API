namespace RithmicApi.Enums
{
	public enum RithmicServerType
	{
		Rithmic_01,
		Rithmic_Demo,
		Rithmic_Germany,
		Rithmic_Demo_singapore,
		Rithmic_Demo_Hong_Kong,
		Rithmic_Demo_Chicago_Area,
		Rithmic_Demo_Chicago_Area2
	}
}
