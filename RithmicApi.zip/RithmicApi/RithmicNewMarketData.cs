namespace RithmicApi
{
	public struct RithmicNewMarketData
	{
		public double Ask { get; set; }

		public double Bid { get; set; }

		public string Symbol { get; set; }
	}
}
